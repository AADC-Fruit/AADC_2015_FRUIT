package org.opencv.test.imgproc;

import org.opencv.test.OpenCVTestCase;

public class MomentsTest extends OpenCVTestCase {

    public void testGet_m00() {
        fail("Not yet implemented");
    }

    public void testGet_m01() {
        fail("Not yet implemented");
    }

    public void testGet_m02() {
        fail("Not yet implemented");
    }

    public void testGet_m03() {
        fail("Not yet implemented");
    }

    public void testGet_m10() {
        fail("Not yet implemented");
    }

    public void testGet_m11() {
        fail("Not yet implemented");
    }

    public void testGet_m12() {
        fail("Not yet implemented");
    }

    public void testGet_m20() {
        fail("Not yet implemented");
    }

    public void testGet_m21() {
        fail("Not yet implemented");
    }

    public void testGet_m30() {
        fail("Not yet implemented");
    }

    public void testGet_mu02() {
        fail("Not yet implemented");
    }

    public void testGet_mu03() {
        fail("Not yet implemented");
    }

    public void testGet_mu11() {
        fail("Not yet implemented");
    }

    public void testGet_mu12() {
        fail("Not yet implemented");
    }

    public void testGet_mu20() {
        fail("Not yet implemented");
    }

    public void testGet_mu21() {
        fail("Not yet implemented");
    }

    public void testGet_mu30() {
        fail("Not yet implemented");
    }

    public void testGet_nu02() {
        fail("Not yet implemented");
    }

    public void testGet_nu03() {
        fail("Not yet implemented");
    }

    public void testGet_nu11() {
        fail("Not yet implemented");
    }

    public void testGet_nu12() {
        fail("Not yet implemented");
    }

    public void testGet_nu20() {
        fail("Not yet implemented");
    }

    public void testGet_nu21() {
        fail("Not yet implemented");
    }

    public void testGet_nu30() {
        fail("Not yet implemented");
    }

    public void testSet_m00() {
        fail("Not yet implemented");
    }

    public void testSet_m01() {
        fail("Not yet implemented");
    }

    public void testSet_m02() {
        fail("Not yet implemented");
    }

    public void testSet_m03() {
        fail("Not yet implemented");
    }

    public void testSet_m10() {
        fail("Not yet implemented");
    }

    public void testSet_m11() {
        fail("Not yet implemented");
    }

    public void testSet_m12() {
        fail("Not yet implemented");
    }

    public void testSet_m20() {
        fail("Not yet implemented");
    }

    public void testSet_m21() {
        fail("Not yet implemented");
    }

    public void testSet_m30() {
        fail("Not yet implemented");
    }

    public void testSet_mu02() {
        fail("Not yet implemented");
    }

    public void testSet_mu03() {
        fail("Not yet implemented");
    }

    public void testSet_mu11() {
        fail("Not yet implemented");
    }

    public void testSet_mu12() {
        fail("Not yet implemented");
    }

    public void testSet_mu20() {
        fail("Not yet implemented");
    }

    public void testSet_mu21() {
        fail("Not yet implemented");
    }

    public void testSet_mu30() {
        fail("Not yet implemented");
    }

    public void testSet_nu02() {
        fail("Not yet implemented");
    }

    public void testSet_nu03() {
        fail("Not yet implemented");
    }

    public void testSet_nu11() {
        fail("Not yet implemented");
    }

    public void testSet_nu12() {
        fail("Not yet implemented");
    }

    public void testSet_nu20() {
        fail("Not yet implemented");
    }

    public void testSet_nu21() {
        fail("Not yet implemented");
    }

    public void testSet_nu30() {
        fail("Not yet implemented");
    }

}
